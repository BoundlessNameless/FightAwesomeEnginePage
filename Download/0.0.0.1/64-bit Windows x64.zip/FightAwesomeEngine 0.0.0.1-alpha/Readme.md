# 战斗爽引擎

注意！这只是一个示例项目并没有任何可玩性，项目仍在开发阶段，用户可以在

Mods\ObjectNeitherSubject\Fighters\BoundlessNameless\FighterConfig.json中修改三千无名这个人物

作者：三千无名

QQ：3484506583

B站主页：[三千无名的个人空间-三千无名个人主页-哔哩哔哩视频 (bilibili.com)](https://space.bilibili.com/330445050?spm_id_from=333.1007.0.0)

项目主页（国外）：https://boundlessnameless.github.io/FightAwesomeEnginePage/

## 目录介绍

FightAwesomeEngine.exe（启动程序）

FighterAwesomeEngine-Log.txt（日志文件仅用于开发者调试）

Mods（模组文件夹）

​	ObjectNeitherSubject（意物模组）

​		Fighters（人物包文件夹）

​			BoundlessNameless（三千无名）

​				Actions（人物动作素材）

​				BoundlessNameless.dll（人物主程序）

​				FighterConfig.json（人物配置文件）

​			FuChuangZi（附窗子）

​				...（同上）

​		BrainUserManual.dll（模组主程序）

​		icon.png（模组图标）

​		ModConfig.json（模组基本配置信息）

Config（配置文件夹）

​	InputPreset（按键映射）

​		Local.json（本地按键映射）

​		Network.json（多人模式联网按键映射）